# IS-105 SEM02 PROSESS

| Filnavn | Beskrivelse |
| ----------- | ----------- |
| **common.h** | En "header"-fil for programmeringsspråket C, som kan inkluderes i kildekode, dvs. i filer som har etternavn ".c". |
| **countem.h** | Programmet teller prosesser, bruker- og kjernerom tråder, som er registrert i det primære minne; dette er et øyeblikksbilde. |
| **cpu.c** | Kildekode i programmeringsspråket C, som implementerer main-funksjonen, som kaller opp en funksjon definert i **common.h**. |
| **nrcores.c** | Returnerer antall kjerner (dette er ikke sikkert i virtuelle miljøer). | 
 
