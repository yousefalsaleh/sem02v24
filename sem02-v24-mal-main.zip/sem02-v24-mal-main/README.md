# sem02-v24-mal
Filer for Seminar II i IS-105 våren 2024 ved UiA.

**runreverse.sh** - et "shellscript" som utfører de utførbare filene for alle programmeringsspråk. Du må ersatte korrekt BASE-mappe. Se i oppgaveteksten for anbefalt struktur av mapper i ditt prosjekt. 
