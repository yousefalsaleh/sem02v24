# For å kompilere C# kildekode og utføre den kompilerte filen med mono

```
$ mcs -out:reverse-bytes-of-file.exe reverse-bytes-of-file.cs
$ mono reverse-bytes-of-file.exe
```
