# For å kompilere Java kildekode og utføre Java bytecode

```
javac ReverseBytesOfFile.java
java ReverseBytesOfFile
```